package com.example.demo;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JarFileSearch {

	public static void main(String[] args) {
        String directoryPath = "C:/Drive/GitRepo/sap.dam.hybris";
        List<String> jarFiles = findJarFiles(directoryPath);
        Collections.sort(jarFiles);
        // Print the names of all JAR files found
        for (String jarFile : jarFiles) {
            System.out.println(jarFile);
        }
    }

    public static List<String> findJarFiles(String directoryPath) {
        List<String> jarFiles = new ArrayList<>();
        Path directory = Paths.get(directoryPath);

        try {
            Files.walkFileTree(directory, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    //if (file.toString().toLowerCase().endsWith(".jar") && !file.getParent().toString().contains("devlib")) {
                	if (file.toString().toLowerCase().endsWith(".jar")) {

                	//System.out.println(file.getFileName().toString() + " : " + file.getParent().toString());
                        jarFiles.add(file.getFileName().toString()+ " : " + file.getParent().toString());
                    }
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }

        return jarFiles;
    }

}
